export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDlK97e7qXkr2HQHk-zasvyrXA9Kbuy8Io",
    authDomain: "sigueme2-2fb1f.firebaseapp.com",
    projectId: "sigueme2-2fb1f",
    storageBucket: "sigueme2-2fb1f.appspot.com", // 👈 NO .firebasestorage.app
    messagingSenderId: "955352494483",
    appId: "1:955352494483:web:1494cbe5993c565ad97866"
  }
};