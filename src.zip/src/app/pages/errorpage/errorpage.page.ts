import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-errorpage',
  templateUrl: './errorpage.page.html',
  styleUrls: ['./errorpage.page.scss'],
  standalone: false,
})
export class ErrorpagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
