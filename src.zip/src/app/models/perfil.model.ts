export interface Perfil {
  correo: string;
  usuario?: string;
  avatar?: string;
}