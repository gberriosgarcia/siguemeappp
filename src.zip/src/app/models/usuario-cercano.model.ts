export interface UsuarioCercano {
  correo: string;
  nombre?: string;
  avatar?: string;
  lat: number;
  lon: number;
}
